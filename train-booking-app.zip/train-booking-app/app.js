// app.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Connect to MongoDB database
mongoose.connect('mongodb://localhost:27017/train_seat_booking', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Define the schema and model for seats
const seatSchema = new mongoose.Schema({
  seatNumber: Number,
  isBooked: Boolean,
});

const Seat = mongoose.model('Seat', seatSchema);

// API endpoint to get all seats with their availability status
app.get('/api/seats', async (req, res) => {
  try {
    const seats = await Seat.find();
    res.json(seats);
  } catch (err) {
    res.status(500).json({ error: 'Error fetching seats from the database.' });
  }
});

// API endpoint for booking seats
app.post('/api/book', async (req, res) => {
  const { numSeats } = req.body;
  try {
    const availableSeats = await Seat.find({ isBooked: false });

    if (availableSeats.length === 0) {
      return res.status(400).json({ error: 'No seats available for booking.' });
    }

    const seatsToBook = availableSeats.slice(0, Math.min(numSeats, 7));

    // Book seats
    await Seat.updateMany(
      { _id: { $in: seatsToBook.map((seat) => seat._id) } },
      { isBooked: true }
    );

    res.json(seatsToBook);
  } catch (err) {
    res.status(500).json({ error: 'Error booking seats.' });
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
